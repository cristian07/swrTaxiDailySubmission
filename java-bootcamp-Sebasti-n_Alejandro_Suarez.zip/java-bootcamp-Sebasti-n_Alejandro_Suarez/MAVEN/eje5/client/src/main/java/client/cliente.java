package client;

public class cliente {

}
