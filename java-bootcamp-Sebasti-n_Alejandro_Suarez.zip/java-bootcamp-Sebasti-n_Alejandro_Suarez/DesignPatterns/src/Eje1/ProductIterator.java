package Eje1;

public interface ProductIterator {
	public Object next();
	public boolean following();
	
}
