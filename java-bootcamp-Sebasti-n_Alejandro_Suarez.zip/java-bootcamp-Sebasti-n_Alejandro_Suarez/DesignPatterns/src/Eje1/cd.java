package Eje1;

public class cd extends Product {
	public cd(double price,int id){super(price,id);}
	@Override
	public String toString(){return "CD";}
}
