package Eje1;

public class dvd extends Product{
	public dvd(double price,int id){super(price,id);}
	@Override
	public String toString(){return "DVD";}
}
