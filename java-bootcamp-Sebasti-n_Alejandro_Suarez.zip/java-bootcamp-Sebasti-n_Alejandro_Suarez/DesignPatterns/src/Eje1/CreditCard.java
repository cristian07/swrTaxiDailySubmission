package Eje1;

public class CreditCard extends Pay {
	public CreditCard(){}
	@Override
	public String toString(){return "Pay with Credit Card";}
}
