package Eje1;

public class Paypal extends Pay{
	public Paypal(){}
	@Override
	public String toString(){return"Pay with Paypal";}
	
	
}
