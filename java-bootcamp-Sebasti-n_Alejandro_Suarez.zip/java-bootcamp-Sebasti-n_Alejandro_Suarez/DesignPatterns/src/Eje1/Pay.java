package Eje1;

public abstract class Pay {
	
	public Pay(){}
	public abstract String toString();
	
}
