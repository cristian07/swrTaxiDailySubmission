package Eje1;

public class Cash extends Pay {
	public Cash(){}
	@Override
	public String toString(){return"Pay with Cash";}
	
}
