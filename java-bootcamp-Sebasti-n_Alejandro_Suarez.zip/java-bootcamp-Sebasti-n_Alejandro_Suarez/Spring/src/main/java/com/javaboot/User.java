package com.javaboot;

public class User {
	public void sayHi(){
		System.out.println("Hi, I'm a user");
	}
}
