package com.javaboot;

public class Principal {
	public static void main(String[] args) {
        // TODO code application logic here
		System.out.println("hola hibernate");
    }

}
