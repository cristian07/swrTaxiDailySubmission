package Controlador;

import org.hibernate.*;


public class Operaciones {
	SessionFactory sesion = NewHibernateUtil.getSessionFactory();
	Session session;
	session=sesion.
	
}
