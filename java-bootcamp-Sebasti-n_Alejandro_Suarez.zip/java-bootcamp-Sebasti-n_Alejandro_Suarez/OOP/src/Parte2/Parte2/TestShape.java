package Parte2.Parte2;


public class TestShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape forma1=new Shape();
		System.out.println(forma1);
		
		Shape forma2=new Shape("azul",false);
		System.out.println(forma2);
		
		Circle circulo1= new Circle();
		System.out.println(circulo1);
	}

}
