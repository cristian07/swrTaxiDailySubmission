

public class TestMyTriangle {

	public static void main(String[] args) {
		MyTriangle triangulo1 = new MyTriangle(0,0,1,0,1,2);
		System.out.println(triangulo1);
		//System.out.println(triangulo1.printType());
	}

}
