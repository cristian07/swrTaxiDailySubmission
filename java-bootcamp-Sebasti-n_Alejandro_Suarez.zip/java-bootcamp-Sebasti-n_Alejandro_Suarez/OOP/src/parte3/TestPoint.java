package parte3;

public class TestPoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Point punto1=new Point(10,20);
		System.out.println(punto1);
		punto1.setXY(100, 10);
		System.out.println(punto1);
	}

}
