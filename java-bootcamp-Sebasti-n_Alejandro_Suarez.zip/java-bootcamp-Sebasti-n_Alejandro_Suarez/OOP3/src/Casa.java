public class Casa extends Edificio{
	public Casa(){}
	@Override
	public String info(){return "Se creo una Casa";}

}
