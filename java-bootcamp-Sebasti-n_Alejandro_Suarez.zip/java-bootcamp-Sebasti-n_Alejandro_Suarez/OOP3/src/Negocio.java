public class Negocio extends Edificio{
	public Negocio(){}
	@Override
	public String info(){return "Se creo un Negocio";}

}
