public abstract class Edificio {
public Edificio(){}
public String info(){return "Edificio generico";}

}
