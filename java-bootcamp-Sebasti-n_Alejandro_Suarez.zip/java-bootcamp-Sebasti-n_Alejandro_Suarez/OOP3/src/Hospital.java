public class Hospital extends Edificio {
	public Hospital(){}
	@Override
	public String info(){return "Se creo un Hospital";}
	
}
