public class Escuela extends Edificio{
	Escuela(){}
	@Override
	public String info(){return "Se creo una Escuela";}

}
